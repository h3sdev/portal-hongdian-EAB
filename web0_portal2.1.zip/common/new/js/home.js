$(".menu-btn").click(function(){
    window.location.href = "homePage.html";
})