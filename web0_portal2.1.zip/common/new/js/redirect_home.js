var redirect_auth = function (params) {
    window.location.href = 'homePage.html';
}
setTimeout(function(){
    redirect_auth();
}, 3000)
