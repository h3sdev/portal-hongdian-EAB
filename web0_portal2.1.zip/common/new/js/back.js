$(".back_btn").click(function(){
    window.location.href = "../../homePage/web/homePage.html"+"?id="+Math.random()+"&?phone="+obtenerCookie()
})


