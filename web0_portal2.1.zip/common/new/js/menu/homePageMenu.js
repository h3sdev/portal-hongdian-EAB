// var orientation = window.orientation;
// var width = window.innerWidth;
// var horizHome = document.getElementById('horizontal_home');
// var verticalHome = document.getElementById('vertical_home');

// function orientacionCambiada() {
    
//     var width = window.innerWidth; // ancho
//     if (orientation === 90)
//     {
//         console.log(window.orientation)
//         console.log(width)
//         verticalHome.style.display = "none";
//         horizHome.style.display = "block";
//     }
//     else if (orientation === 0)
//     {
//         console.log(window.orientation)
//         console.log(width)
//         verticalHome.style.display = "block";
//         horizHome.style.display = "none";
//     }
//     else if (width > 800)
//     {
//         console.log(window.orientation)
//         console.log(width)
//         verticalHome.style.display = "none";
//         horizHome.style.display = "block";
//     }
// }
// window.addEventListener("orientationchange", orientacionCambiada, false);
// window.addEventListener("load", orientacionCambiada, false);
// document.addEventListener("onresize", orientacionCambiada, false);
