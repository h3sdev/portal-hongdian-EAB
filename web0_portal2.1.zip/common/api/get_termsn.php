<?php
require_once("get_config.php");
//获取设备sn
$termSn = getTermSn();
return $termSn;
?>
