#!/bin/sh
#hasta que exista el archivo haga loop para pasarlo

existe(){
    chmod 777 /etc/rc.local
}

existe &