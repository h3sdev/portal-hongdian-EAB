$(document).ready(function() {
    window.oncontextmenu = function() {
        return false;
    } 
});