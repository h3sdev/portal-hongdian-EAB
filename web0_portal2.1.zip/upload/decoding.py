import urllib
eur=urllib.unquote("hellowa3423g%3b%2f%2f%27%27%22%5c%c3%bc92%c3%ad2%5c9%e2%86%94").decode('utf8')
print(eur)